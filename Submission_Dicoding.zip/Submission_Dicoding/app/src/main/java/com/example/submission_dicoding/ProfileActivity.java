package com.example.submission_dicoding;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class ProfileActivity extends AppCompatActivity {
    private RecyclerView profile;
    private ArrayList<Profile> listP =new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profile = findViewById(R.id.profile_main);
        profile.setHasFixedSize(true);

        listP.addAll(ProfileData.getProfileList());
        showProfile();
    }

    private void showProfile(){
        profile.setLayoutManager(new LinearLayoutManager(this));
        profileAdapter listProfileAdapter = new profileAdapter(listP);
        profile.setAdapter(listProfileAdapter);
    }
}
