package com.example.submission_dicoding;

import java.util.ArrayList;
import java.util.Collection;

public class ProfileData {
    private static String[][] myProfile = new String[][]{{"Firman Noor Praadita","firman.praa@gmail.com"}};
    private static int[] image = {R.drawable.man};

    public static ArrayList<Profile> getProfileList() {
        ArrayList<Profile> dataProfile = new ArrayList<>();

        for (String[] temp: myProfile){
            Profile pr = new Profile();
            pr.setName(temp[0]);
            pr.setEmail(temp[1]);
            pr.setImage(image[0]);

            dataProfile.add(pr);
        }
        return dataProfile;
    }

}
