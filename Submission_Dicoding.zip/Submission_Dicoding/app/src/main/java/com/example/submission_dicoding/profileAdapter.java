package com.example.submission_dicoding;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class profileAdapter extends RecyclerView.Adapter<profileAdapter.profileViewHolder> {
    private ArrayList<Profile> listProfile;

    public profileAdapter(ArrayList<Profile> listProfile) {
        this.listProfile = listProfile;
    }

    @NonNull
    @Override
    public profileViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.activity_profile, viewGroup, false);
        return new profileViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final profileViewHolder holder, int position) {

        final Profile pr = listProfile.get(position);

        Glide.with(holder.itemView.getContext())
                .load(pr.getImage())
                .into(holder.imgProfile);

        holder.prName.setText(pr.getName());
        holder.prEmail.setText(pr.getEmail());
    }

    @Override
    public int getItemCount() {
        return listProfile.size();

    }

    class profileViewHolder extends RecyclerView.ViewHolder {
        ImageView imgProfile;
        TextView prName, prEmail;

        profileViewHolder(@NonNull View itemView) {
            super(itemView);
            imgProfile = itemView.findViewById(R.id.profile);
            prName = itemView.findViewById(R.id.name);
            prEmail = itemView.findViewById(R.id.email);
        }
    }
}
